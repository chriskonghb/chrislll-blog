import{z as s}from"./BEYqC3Xw.js";const t=s("/chris-avatar.jpg");export{t as _};
