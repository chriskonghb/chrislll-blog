import{V as t,W as e}from"./BEYqC3Xw.js";const n=t(()=>{if(!localStorage.getItem("token"))return e("/admin/login")});export{n as default};
